package com.example.library;

import java.util.Date;

public class getData {
    public static String studentNumber;
    public static String path;

    public static String pathImage;
    public static String takeBookTitle;

    //saved
    public static String savedTitle;
    public static String savedAuthor;
    public static String savedGenre;
    public static String savedImage;
    public static Date savedDate;
}
