package com.example.library;


import javafx.animation.TranslateTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.EventObject;
import java.util.ResourceBundle;




public class dashboardController implements Initializable {


    @FXML
    private Button availableBooks_btn;

    @FXML
    private AnchorPane availableBooks_form;

    @FXML
    private ImageView availableBooks_imageView;

    @FXML
    private TableView<availableBooks> availableBooks_tableView;

    @FXML
    private Label availableBooks_title;

    @FXML
    private Circle circle_image;

    @FXML
    private TableColumn<availableBooks, String> col_ab_author;

    @FXML
    private TableColumn<availableBooks, String> col_ab_bookTitle;

    @FXML
    private TableColumn<availableBooks, String> col_ab_bookType;

    @FXML
    private TableColumn<availableBooks, String> col_ab_publishedDate;

    @FXML
    private Button edit_btn;

    @FXML
    private Button issueBooks_btn;

    @FXML
    private Button logout_btn;

    @FXML
    private Button returnBooks_btn;

    @FXML
    private Button save_btn;

    @FXML
    private Button savedBooks_btn;

    @FXML
    private Label studentNumber_label;

    @FXML
    private Button take_btn;

    @FXML
    private Button close;

    @FXML
    private Button minimize;

    @FXML
    private Button arrow_btn;

    @FXML
    private Button bars_btn;

    @FXML
    private AnchorPane nav_form;

    @FXML
    private AnchorPane mainCenter_form;

    @FXML
    private Button halfNav_availableBtn;

    @FXML
    private AnchorPane halfNav_form;

    @FXML
    private Button halfNav_returnBtn;

    @FXML
    private Button halfNav_saveBtn;

    @FXML
    private Button halfNav_takeBtn;
    @FXML
    private Label currentForm_label;

    @FXML
    private Circle smallCircle_image;
    @FXML
    private AnchorPane issue_form;
    @FXML
    private AnchorPane returnBook_form;
    @FXML
    private AnchorPane savedBook_form;

    private Image image;
    private Connection connect;
    private PreparedStatement prepare;
    private ResultSet result;


        private ObservableList<availableBooks> listBook;

    public void showAvailableBooks() {

        listBook = dataList();

        col_ab_bookTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        col_ab_author.setCellValueFactory(new PropertyValueFactory<>("author"));
        col_ab_bookType.setCellValueFactory(new PropertyValueFactory<>("genre"));
        col_ab_publishedDate.setCellValueFactory(new PropertyValueFactory<>("date"));

        availableBooks_tableView.setItems(listBook);

    }

    public void selectAvailableBooks() {
        availableBooks bookData = availableBooks_tableView.getSelectionModel().getSelectedItem();

        int num = availableBooks_tableView.getSelectionModel().getFocusedIndex();
        if ((num-1) <-1)
            return;

        
        

         
        availableBooks_title.setText(bookData.getTitle());

        String uri = ("file:"+ bookData.getImage());

        image = new Image(uri,130,162,false,true);
        availableBooks_imageView.setImage(image);

    }

    public void abTakeButton(ActionEvent event) {

        if (event.getSource() == take_btn) {
            issue_form.setVisible(true);
            availableBooks_form.setVisible(false);


            currentForm_label.setText("Issue Books");

        }
    }

public void studentNumber(){
    studentNumber_label.setText(getData.studentNumber);
}
    public ObservableList<availableBooks> dataList() {

        ObservableList<availableBooks> listBooks = FXCollections.observableArrayList();

        String sql = "SELECT * FROM book";

        connect = Database.connectDB();

        try {

            availableBooks aBooks;

            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();

            while (result.next()) {

                aBooks = new availableBooks(result.getString("bookTitle"),
                        result.getString("author"), result.getString("bookType"),
                        result.getString("image"), result.getDate("date"));

                listBooks.add(aBooks);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return listBooks;
    }




        private EventObject event;
        private Object resources;


        public void sliderArrow () {

            TranslateTransition slide = new TranslateTransition();

            slide.setDuration(Duration.seconds(.5));
            slide.setNode(nav_form);
            slide.setToX(-224);

            TranslateTransition slide1 = new TranslateTransition();

            slide1.setDuration(Duration.seconds(.5));
            slide1.setNode(mainCenter_form);
            slide1.setToX(-224 + 90);

            TranslateTransition slide2 = new TranslateTransition();
            slide2.setDuration(Duration.seconds(.5));
            slide2.setNode(halfNav_form);
            slide2.setToX(0);

            slide.setOnFinished((ActionEvent event) -> {

                arrow_btn.setVisible(false);
                bars_btn.setVisible(true);

            });

            slide2.play();
            slide1.play();
            slide.play();

        }
        public void sliderBars () {

            TranslateTransition slide = new TranslateTransition();

            slide.setDuration(Duration.seconds(.5));
            slide.setNode(nav_form);
            slide.setToX(0);

            TranslateTransition slide1 = new TranslateTransition();

            slide1.setDuration(Duration.seconds(.5));
            slide1.setNode(mainCenter_form);
            slide1.setToX(0);

            TranslateTransition slide2 = new TranslateTransition();
            slide2.setDuration(Duration.seconds(.5));
            slide2.setNode(halfNav_form);
            slide2.setToX(-77);

            slide.setOnFinished((ActionEvent event) -> {

                arrow_btn.setVisible(true);
                bars_btn.setVisible(false);

            });

            slide2.play();
            slide1.play();
            slide.play();
        }

        private double x = 0;
        private double y = 0;
        @FXML
        public void logout (ActionEvent event){
            try {
                if (event.getSource() == logout_btn) {

                    // TO SWAP FROM DASHBOARD TO LOGIN FORM


                    Parent root = FXMLLoader.load(getClass().getResource("Library-view.fxml"));

                    Stage stage = new Stage();
                    Scene scene = new Scene(root);

                    root.setOnMousePressed((MouseEvent e) -> {
                        x = e.getSceneX();
                        y = e.getSceneY();
                    });

                    root.setOnMouseDragged((MouseEvent e) -> {

                        stage.setX(e.getScreenX() - x);
                        stage.setY(e.getScreenY() - y);

                    });

                    stage.initStyle(StageStyle.TRANSPARENT);

                    stage.setScene(scene);
                    stage.show();

                    logout_btn.getScene().getWindow().hide();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


        public void exit () {

            System.exit(0);

        }
        public void minimize () {

            Stage stage = (Stage) minimize.getScene().getWindow();
            stage.setIconified(true);


        }
        @Override
        public void initialize (URL location, ResourceBundle resources){
            showAvailableBooks();
            studentNumber();
        }

    }

